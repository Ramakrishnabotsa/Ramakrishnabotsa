var wraper = document.getElementsByClassName("wraper");
wraper[0].style.backgroundColor = "black";

var container = document.getElementsByClassName("container");
container[0].style.width = "950px";
container[0].style.margin = "0 auto";
container[0].style.backgroundColor = "yellow";
var logo = document.getElementsByClassName('logo');
logo[0].style.padding = "30px 0";
 var nav = document.getElementsByTagName('nav');
 nav[0].style.padding = "20px 0";

var ul = document.getElementsByTagName('ul');
for (var i = 0; i < ul.length; i++) {
    ul[i].style.listStyleType = "none";
}
var li = document.getElementsByTagName('li');
for (var i = 0; i < li.length; i++) {
    li[i].style.display = "inline-block";
}
var a = document.getElementsByTagName('a');
for (var i = 0; i < a.length; i++) {
    a[i].style.textDecoration = "none";
    a[i].style.marginLeft = "20px";
    a[i].style.paddingBottom = "20px";
}
var img = document.getElementsByTagName('img');
img[1].style.maxWidth = "100%";
var parent = document.getElementsByClassName('parent');
for (var i = 0; i < parent.length; i++) {
    parent[i].style.display = "flex";
}
var naniba = document.getElementsByClassName('naniba');
for(var i=0; i<naniba.length;i++){
    naniba[i].style.margin = "20px ";
}
var panduna = document.getElementsByClassName('panduna');
for(var i=0; i<panduna.length;i++){
    panduna[i].style.margin = "20px ";
}
var h2 = document.getElementsByTagName('h2');
h2[0].style.paddingTop = "20px";
h2[0].style.fontSize = "20px";
h2[0].style.lineHeight = "17px";
h2[0].style.color = "#010409";
h2[0].style.textAlign= "start";

var h2 = document.getElementsByTagName('h2');
h2[1].style.paddingTop = "20px";
h2[1].style.fontSize = "20px";
h2[1].style.lineHeight = "17px";
h2[1].style.color = "#010409";
h2[1].style.textAlign = "start";

var p = document.getElementsByTagName('p');
p[0].style.paddingTop = "33px";
p[0].style.fontSize = "14px";
p[0].style.lineHeight = "20px";
p[0].style.color = "#010409";
p[0].style.justifyContent = "ends";

var p = document.getElementsByTagName('p');
p[1].style.paddingTop = "33px";
p[1].style.fontSize = "14px";
p[1].style.lineHeight = "20px";
p[1].style.color = "#010409";
p[1].style.textAlign = "start";

var footer = document.getElementsByTagName('footer');
for(  var i=0; i<footer.length; i++){
    footer[i].style.backgroundColor = "grey";
    footer[i].style.textAlign = "center";
    footer[i].style.padding = "8px 0";

}
